<html>
<head></head>
<body style="background: black; color: white">
<h1><?php echo e($title); ?></h1>
<p><?php echo e($content); ?></p>
</body>
</html>
