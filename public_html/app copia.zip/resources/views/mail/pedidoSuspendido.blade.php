<html>
<head></head>
<body style="background: black; color: white">
<h1>{{$title}}</h1>
<p>{{$content}}</p>
</body>
</html>
