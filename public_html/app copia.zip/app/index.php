<?php

echo "lalala";;

