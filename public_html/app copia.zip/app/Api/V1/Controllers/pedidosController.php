<?php

namespace App\Api\V1\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use Dingo\Api\Routing\Helpers;
use App\Http\Controllers\Controller;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Event;
use App\Http\lib\firebaseApp;
use App\Events\notificacionMail;
use App\Api\V1\Domain\Pedidos\pedidosAviso;
use App\Api\V1\Domain\Pedidos\pedidoConfirmado;
use App\Api\V1\Domain\Pedidos\pedidoSuspender;

class pedidosController extends Controller {

    //helper
    use Helpers;

    protected $firebase;

    public function __construct() {
        $this->firebase = new firebaseApp();
    }

    public function recibirPedido(Request $request) {
        $data  = $request->all();
        return 999;
        $idVendedor = $data['data']["usuario_id_venta"];
        $token =  $data['data']["token"];
        $email = $this->firebase->get('users/' . $idVendedor . '/email');
        //return $data;
        $mailContent = pedidosAviso::MailFormato(json_decode($email),$token);
        $e = Event::fire(new notificacionMail($mailContent));
        return response()->json(array("status"=>200,"orden"=> $e));
    }

    public function confirmarPedido(Request $request,$id) {
        //return $id;
        //return (array)json_decode($this->firebase->get('pedidos',array('orderBy' => '"estado"','equalTo'=>'"c"')));
        $idPedido = pedidoConfirmado::getFromToken($id);
        $pedido = (array) json_decode($this->firebase->get(pedidoConfirmado::DOMAIN . '/' . $idPedido));
        $usuario_comprador = $pedido['usuario_id'];
        $email = $this->firebase->get('users/' . $usuario_comprador . '/email');
        $mailContent = pedidoConfirmado::MailFormato(json_decode($email));
        
        //$this->firebase->update(pedidoConfirmado::DOMAIN . '/' . $idPedido . '/' . pedidoConfirmado::CAMPO_ESTADO, pedidoConfirmado::VALUE);
        Event::fire(new notificacionMail($mailContent));
        
        return response()->json(array("status"=>200));
    }

    public function  suspenderPedido(Request $request){
        $data = $request->all();
        $idPedido = $data['data']['pedido_id'];
        $idUsuario = $data['data']['usuario_id'];
        $value = pedidoSuspender::VALUE;
        $email = $this->firebase->get('users/' . $idUsuario . '/email');
        //$this->firebase->update(pedidoSuspender::DOMAIN. '/' . $idPedido . '/'. pedidoSuspender::CAMPO_ESTADO , $value);
        
        $mailContent = pedidoSuspender::MailFormato(json_decode($email));
        $eventMail = Event::fire(new notificacionMail($mailContent));
        return response()->json(array("status"=>200));
    }
    
    public function finalizarPedido(Request $request){
        $idPedido = $request->get('idPedido');
        $value = $request->get('value');
        $this->firebase->update($this->domain . '/' . $idPedido . '/' . $this->campo, $value);
        $email="javiervelaz@hotmail.com";
        $request = array(
            'title' => 'compra confirmada event',
            'content' => 'test confirmacion compra',
            'mailVendedor' => $email,
            'template' => 'mail.avisoCompra'
        );
        
        Event::fire(new notificacionMail($request));
        
    }
    
}
