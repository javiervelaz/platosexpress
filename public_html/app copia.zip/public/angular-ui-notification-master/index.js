/**
 * Created by alex_crack on 20.11.15.
 */
require('./dist/angular-ui-notification.js');
module.exports = 'ui-notification';