//angular.module('routes',['ngRoutes'])

//angular.module('routes').config(function($routeProvider){
//    $routeProvider.when('/about',{
//        templateUrl : 'aboutus.html',
//        controller : 'aboutController'
//    })
//});

