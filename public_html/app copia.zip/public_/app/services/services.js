(function() {

  'use strict';

  /* Services */


  angular.module('app.services', ['app.service.firebase']).
    value('version', '0.1');
})();


