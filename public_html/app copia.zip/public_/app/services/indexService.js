angular.module('indexService',[])
        .factory('index',function($http){
            return true;
        });


