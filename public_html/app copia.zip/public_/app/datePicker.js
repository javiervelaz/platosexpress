angular
        .module('app')
        .controller('Ctrl',picker);

function picker(){
    var self = this;
    console.log(self);
}